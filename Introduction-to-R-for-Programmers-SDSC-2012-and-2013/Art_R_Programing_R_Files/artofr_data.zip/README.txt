
Files:

Each of the files whose name has the suffix ".short" is a shortened
version of the original, consisting of approximately the first 100
records.

1.  Grades.txt 

   Sections 1.5, 5.1.2.

   This is from one of my course (not the one in the book, which seems
   to be lost).  Variables are now a bit different.

2.  Abalone.data, Abalone.names

   Sections 2.9.2, 4.4.3.

   These are from the UC Irvine Machine Learning data set repository,
   http://archive.ics.uci.edu/ml/datasets/Abalone

3.  2006.csv

   Section 10.2.4.

   Data are from the Dept. of Labor Web site,

   http://www.flcdatacenter.com/CasePerm.aspx
  
4.  PUMS5_06.TXT

   From the U.S. Census Bureau site.


